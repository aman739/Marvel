package com.example.marvel.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.marvel.base.BaseDiffUtil
import com.example.marvel.data.dtos.AnimeModel
import com.example.marvel.databinding.ItemAnimeBinding

class AnimeAdapter : ListAdapter<AnimeModel, AnimeAdapter.AnimeViewHolder>(BaseDiffUtil()) {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): AnimeViewHolder =
        AnimeViewHolder(
            ItemAnimeBinding.inflate(
                LayoutInflater.from(
                    parent.context
                ),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: AnimeAdapter.AnimeViewHolder, position: Int) {
        getItem(position)?.let {
            holder.onBind(it)
        }
    }

    class AnimeViewHolder(private val binding: ItemAnimeBinding):
            RecyclerView.ViewHolder(binding.root){
                fun onBind (data:AnimeModel){
                    binding.tvCharac.text = data.character
                    binding.startDateTv.text = data.anime
                }
            }

}