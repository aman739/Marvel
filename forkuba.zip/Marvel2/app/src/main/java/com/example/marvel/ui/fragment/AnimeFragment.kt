package com.example.marvel.ui.fragment

import android.util.Log
import androidx.fragment.app.viewModels
import by.kirich1409.viewbindingdelegate.viewBinding
import com.example.marvel.base.BaseFragment
import com.example.marvel.ui.adapter.AnimeAdapter
import com.example.marvel.R
import com.example.marvel.databinding.FragmentAnimeBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AnimeFragment :BaseFragment<AnimeViewModel, FragmentAnimeBinding>(
    R.layout.fragment_anime
){
    override val viewModel : AnimeViewModel by viewModels()
    override val binding by viewBinding(FragmentAnimeBinding::bind)
    private val animeAdapter = AnimeAdapter()

    override fun setupSubscribe() {
        viewModel.animeState.collectUIState(
         error = {
             Log.e("bankai ", it)
         },
            success = {
                animeAdapter.submitList(it)
                Log.e("akashi" ,it.toString() )
            }
        )
    }

    override fun setupViews() {
        setupAdapter()
    }
    private fun setupAdapter(){
        binding.recyclerView.apply {
            adapter = animeAdapter
        }
    }
}
