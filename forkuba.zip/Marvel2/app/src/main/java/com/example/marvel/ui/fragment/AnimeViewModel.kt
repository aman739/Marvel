package com.example.marvel.ui.fragment

import com.example.marvel.base.BaseViewModel
import com.example.marvel.data.dtos.AnimeModel
import com.example.marvel.data.repositories.AnimeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

@HiltViewModel
class AnimeViewModel @Inject constructor(private val animeRepository: AnimeRepository) :
    BaseViewModel() {
    private val _animeState = mutableUIStateFlow<List<AnimeModel>>()
    val animeState = _animeState.asStateFlow()

    fun fetchAnime() {
        animeRepository.fetchAnime().collectRequest(_animeState)
    }
    init {
        fetchAnime()
    }

}


