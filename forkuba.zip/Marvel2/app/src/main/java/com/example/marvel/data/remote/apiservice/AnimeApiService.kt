package com.example.marvel.data.remote.apiservice

import com.example.marvel.data.dtos.AnimeModel
import retrofit2.http.GET

interface AnimeApiService {
    @GET("quotes")
    suspend fun fetchAnime():List<AnimeModel>
}