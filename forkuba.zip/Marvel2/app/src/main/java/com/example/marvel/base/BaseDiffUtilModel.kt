package com.example.marvel.base

interface BaseDiffUtilModel {
    val anime: String
    override fun equals(other: Any?): Boolean
}