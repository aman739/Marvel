package com.example.marvel.data.dtos

import com.example.marvel.base.BaseDiffUtilModel
import com.google.gson.annotations.SerializedName

data class AnimeModel(
    @SerializedName("anime")
    override val anime : String,
    @SerializedName("character")
    val character : String,
    @SerializedName("quote")
    val quote : String,
): BaseDiffUtilModel
