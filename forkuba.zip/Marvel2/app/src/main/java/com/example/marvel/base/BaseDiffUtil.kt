package com.example.marvel.base

import androidx.recyclerview.widget.DiffUtil

class BaseDiffUtil<T: BaseDiffUtilModel> : DiffUtil.ItemCallback<T>() {
    override fun areItemsTheSame(oldItem: T, newItem: T): Boolean =
        oldItem.anime == newItem.anime

    override fun areContentsTheSame(oldItem: T, newItem: T): Boolean =
        oldItem == newItem
}