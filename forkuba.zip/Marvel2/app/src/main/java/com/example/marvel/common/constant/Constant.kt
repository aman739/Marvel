package com.example.marvel.common.constant

object Constant {
    const val BASE_URL: String = "https://animechan.vercel.app/api/"
}