package com.example.marvel.data.repositories

import com.example.marvel.base.BaseRepository
import com.example.marvel.data.remote.apiservice.AnimeApiService
import javax.inject.Inject

class AnimeRepository @Inject constructor(
    private val service:AnimeApiService
): BaseRepository(){
    fun fetchAnime()= doRequest {
        service.fetchAnime()
    }
}
